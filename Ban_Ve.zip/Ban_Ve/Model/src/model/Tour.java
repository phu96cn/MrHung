/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;


public class Tour implements Serializable{
    private int Matour;
    private String Tentour;
    private String Noidi;
    private Diadiem Diadiem;
    private float giatour;
    private String Mota;
    public Tour(int Matour, String Tentour, String Noidi, Diadiem Diadiem, float giatour, String Mota) {
        this.Matour = Matour;
        this.Tentour = Tentour;
        this.Noidi = Noidi;
        this.Diadiem = Diadiem;
        this.giatour = giatour;
        this.Mota = Mota;
    }

    public Tour() {
    }

    public int getMatour() {
        return Matour;
    }

    public void setMatour(int Matour) {
        this.Matour = Matour;
    }

    public String getTentour() {
        return Tentour;
    }

    public void setTentour(String Tentour) {
        this.Tentour = Tentour;
    }

    public String getNoidi() {
        return Noidi;
    }

    public void setNoidi(String Noidi) {
        this.Noidi = Noidi;
    }

    public Diadiem getDiadiem() {
        return Diadiem;
    }

    public void setDiadiem(Diadiem Diadiem) {
        this.Diadiem = Diadiem;
    }

    public float getGiatour() {
        return giatour;
    }

    public void setGiatour(float giatour) {
        this.giatour = giatour;
    }

    public String getMota() {
        return Mota;
    }

    public void setMota(String Mota) {
        this.Mota = Mota;
    }

    public Object[] toObjects(){
        return new Object[]{this.Matour,this.Tentour, this.Noidi, this.Diadiem, this.giatour, this.Mota};
    }

}

