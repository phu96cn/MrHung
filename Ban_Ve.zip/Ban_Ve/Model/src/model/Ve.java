/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

public class Ve implements Serializable{
    private int MaVe;
    private Tour Tour;
    private KhachHang Khachhang;
    private String Noidi;
    private Diadiem Diadiem;
    private String Ngaydi;
    private int Soluongkhach;
    private float Tongtien;

    public Ve() {
    }

    public Ve(int MaVe, Tour Tour, KhachHang Khachhang, String Noidi, Diadiem Diadiem, String Ngaydi, int Soluongkhach, float Tongtien) {
        this.MaVe = MaVe;
        this.Tour = Tour;
        this.Khachhang = Khachhang;
        this.Noidi = Noidi;
        this.Diadiem = Diadiem;
        this.Ngaydi = Ngaydi;
        this.Soluongkhach = Soluongkhach;
        this.Tongtien = Tongtien;
    }
    
    public int getMaVe() {
        return MaVe;
    }

    public void setMaVe(int MaVe) {
        this.MaVe = MaVe;
    }

    public Tour getTour() {
        return Tour;
    }

    public void setTour(Tour Tour) {
        this.Tour = Tour;
    }

    public KhachHang getKhachhang() {
        return Khachhang;
    }

    public void setKhachhang(KhachHang Khachhang) {
        this.Khachhang = Khachhang;
    }

    public String getNoidi() {
        return Noidi;
    }

    public void setNoidi(String Noidi) {
        this.Noidi = Noidi;
    }

    public Diadiem getDiadiem() {
        return Diadiem;
    }

    public void setDiadiem(Diadiem Diadiem) {
        this.Diadiem = Diadiem;
    }

    public String getNgaydi() {
        return Ngaydi;
    }

    public void setNgaydi(String Ngaydi) {
        this.Ngaydi = Ngaydi;
    }

    public int getSoluongkhach() {
        return Soluongkhach;
    }

    public void setSoluongkhach(int Soluongkhach) {
        this.Soluongkhach = Soluongkhach;
    }

    public float getTongtien() {
        return Tongtien;
    }

    public void setTongtien(float Tongtien) {
        this.Tongtien = Tongtien;
    }

    public Object[] toObjects(){
        return new Object[]{this.MaVe,this.Tour, this.Khachhang, this.Noidi, this.Diadiem, this.Ngaydi, this.Soluongkhach, this.Tongtien};
    }
}
