/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

public class KhachHang implements Serializable{   
    private int MaKH;
    private String TenKH;
    private String ID;
    private String LoaiID;
    private String Sdt;
    private String Email;
    private String Diachi;

    public KhachHang(int MaKH, String TenKH, String ID, String LoaiID, String Sdt, String Email, String Diachi) {
        this.MaKH = MaKH;
        this.TenKH = TenKH;
        this.ID = ID;
        this.LoaiID = LoaiID;
        this.Sdt = Sdt;
        this.Email = Email;
        this.Diachi = Diachi;
    }
    
    public KhachHang() {
    }

    public int getMaKH() {
        return MaKH;
    }

    public void setMaKH(int MaKH) {
        this.MaKH = MaKH;
    }

    public String getTenKH() {
        return TenKH;
    }

    public void setTenKH(String TenKH) {
        this.TenKH = TenKH;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getLoaiID() {
        return LoaiID;
    }

    public void setLoaiID(String LoaiID) {
        this.LoaiID = LoaiID;
    }

    public String getSdt() {
        return Sdt;
    }

    public void setSdt(String Sdt) {
        this.Sdt = Sdt;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getDiachi() {
        return Diachi;
    }

    public void setDiachi(String Diachi) {
        this.Diachi = Diachi;
    }

}
