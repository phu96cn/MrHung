/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;

public class Diadiem implements Serializable{
    private int MaDd;
    private String TenDd;
    private String Diachi;
    private String Mota;

    public Diadiem(int MaDd, String TenDd, String Diachi, String Mota) {
        this.MaDd = MaDd;
        this.TenDd = TenDd;
        this.Diachi = Diachi;
        this.Mota = Mota;
    }
    
    public Diadiem() {
    }

    public int getMaDd() {
        return MaDd;
    }

    public void setMaDd(int MaDd) {
        this.MaDd = MaDd;
    }

    public String getTenDd() {
        return TenDd;
    }

    public void setTenDd(String TenDd) {
        this.TenDd = TenDd;
    }

    public String getDiachi() {
        return Diachi;
    }

    public void setDiachi(String Diachi) {
        this.Diachi = Diachi;
    }

    public String getMota() {
        return Mota;
    }

    public void setMota(String Mota) {
        this.Mota = Mota;
    }

    public Object[] toObjects(){
        return new Object[]{this.MaDd,this.TenDd, this.Diachi, this.Mota};
    }
}
