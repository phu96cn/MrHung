/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

public class TayDua implements Serializable{   
    private int Id;
    private DoiDua doidua;
    private String Ten;
    private String NgaySinh;
    private String QuocTich;
    private String TieuSu;

    public TayDua(int Id, DoiDua IdDoi, String Ten, String NgaySinh, String QuocTich, String TieuSu) {
        this.Id = Id;
        this.doidua = IdDoi;
        this.Ten = Ten;
        this.NgaySinh = NgaySinh;
        this.QuocTich = QuocTich;
        this.TieuSu = TieuSu;
    }

    public TayDua() {
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public DoiDua getDoidua() {
        return doidua;
    }

    public void setDoidua(DoiDua doidua) {
        this.doidua = doidua;
    }

    public String getTen() {
        return Ten;
    }

    public void setTen(String Ten) {
        this.Ten = Ten;
    }

    public String getNgaySinh() {
        return NgaySinh;
    }

    public void setNgaySinh(String NgaySinh) {
        this.NgaySinh = NgaySinh;
    }

    public String getQuocTich() {
        return QuocTich;
    }

    public void setQuocTich(String QuocTich) {
        this.QuocTich = QuocTich;
    }

    public String getTieuSu() {
        return TieuSu;
    }

    public void setTieuSu(String TieuSu) {
        this.TieuSu = TieuSu;
    }

    
    public Object[] toObjects(){
        return new Object[]{this.Id, this.doidua, this.Ten, this.NgaySinh, this.QuocTich};
    }
}
