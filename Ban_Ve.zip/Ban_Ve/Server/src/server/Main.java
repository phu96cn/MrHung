/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Main extends Thread {

    private int port;
    private long time;

    public Main(int Serverport, long time) {
        this.port = Serverport;
        this.time = time;
    }

    public void run() {
        try {
            Server server = new Server();
            this.sleep(time);
            try {
                server.openServer(port);
                server.service();
            } catch (Exception ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {
        Main m = new Main(7575,2000);
        m.start();
    }
}
