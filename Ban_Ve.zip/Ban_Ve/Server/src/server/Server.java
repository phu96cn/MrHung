/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import dao.ConnectDBTour;
import dao.ConnectDBKhachhang;
import dao.ConnectDBTK;
import dao.ConnectDBDiadiem;
import dao.ConnectDBVe;
//import static dao.ConnectDBDiadiem.arlMoTa;
//import static dao.ConnectDBDiadiem.arlTinhTrang;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import model.Admin;
import model.Tour;
import model.Diadiem;
import model.KhachHang;
import model.Ve;


public class Server {

    private ObjectInputStream input;
    private ObjectOutputStream output;
    private ServerSocket myServer;
    private Socket clientSocket;

    public void openServer(int serverPort) throws Exception {
        myServer = new ServerSocket(serverPort);
    }

    public Object receiveObject() throws Exception {
        ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());
        return ois.readObject();
    }

    public void sendResult(Object obj) throws Exception {
        ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream());
        oos.writeObject(obj);
    }

    public void service() throws Exception {
        System.out.println("Server opening...");
        while (true) {
            clientSocket = myServer.accept();
            System.out.println("kết nối thành công...");
            String request = (String) receiveObject();
            switch (request) {
                case "Login": {
                    Admin tk = (Admin) receiveObject();
                    if (ConnectDBTK.checkLogin(tk)) {
                        sendResult("success");
                    } else {
                        sendResult("fail");
                    }
                    break;
                }
                case "TimTourtheodiemden": {
                    String var = (String) receiveObject();
                    ArrayList<Tour> arlS = ConnectDBTour.timTourtheodiemden(var);
                    sendResult(arlS);
                    break;
                }
                case "TimKhachHangtheoID": {
                    int id = (int) receiveObject();
                    KhachHang kh = ConnectDBKhachhang.timKhachhangtheoid(id);
                    sendResult(kh);
                    break;
                }
                case "TimKhachHangtheoSoID": {
                    String soID = (String) receiveObject();
                    String Loai = (String) receiveObject();
                    KhachHang kh = ConnectDBKhachhang.timKhachhangtheoSoid(soID,Loai);
                    sendResult(kh);
                    break;
                }
                case "ThemKhachhang": {
                    KhachHang kh = (KhachHang) receiveObject();
                    ConnectDBKhachhang.ThemKH(kh);
                    sendResult("success");
                    break;
                }
                case "ThemVe": {
                    Ve ve = (Ve) receiveObject();
                    ConnectDBVe.ThemVe(ve);
                    sendResult("success");
                    break;
                }
                case "CheckveKH": {
                    int MaKH = (int) receiveObject();
                    String ngay = (String) receiveObject();
                    //System.out.println("kết nối thành công...");
                    sendResult(ConnectDBVe.CheckVeKH(MaKH, ngay));
                }
               /* case "CapNhatChang": {
                    Tour ch = (Tour)receiveObject();
                    if (ConnectDBTour.capNhatChang(ch)) {
                        sendResult("success");
                    } else {
                        sendResult("fail");
                    }
                    break;
                }
  /*              case "SuaBD": {
                    Chang bd = (Chang) receiveObject();
                    if (ConnectDBChang.capNhatBanDoc(bd)) {
                        sendResult("success");
                    } else {
                        sendResult("fail");
                    }
                    break;
                }
                case "timSach": {
                    String tenS = (String) receiveObject();
                    ArrayList<TayDua> arlS = ConnectDBTayDua.timSachTheoTen(tenS);
                    sendResult(arlS);
                    break;
                }
                case "SuaSach": {
                    TayDua s = (TayDua) receiveObject();
                    if (ConnectDBTayDua.capNhatSach(s)) {
                        sendResult("success");
                    } else {
                        sendResult("fail");
                    }
                    break;
                }
                case "ThemPhieuMuon": {
                    DangKi phieuMuon = (DangKi) receiveObject();
                    ConnectDBDk.themDanhSachSachMuon(phieuMuon);
                    sendResult("success");
                    ArrayList<PMTemp> arl = ConnectDBDk.docPMT();
                    sendResult(arl);
                    break;
                }
                case "HTSachMuonCuaBD": {
                    int maphieu = (int) receiveObject();
                    ArrayList<TayDua> arl = ConnectDBDk.docSachTheoPhieu(maphieu);
                    sendResult(arl);
                    break;
                }
                case "CheckBanDoc": {
                    Chang bd = (Chang) receiveObject();
                    if (ConnectDBDk.checkBanDoc(bd.getMaBD())) {
                        sendResult("true");
                    } else {
                        sendResult("false");
                    }
                    break;
                }
                case "TimPhieuMuon": {
                    int maPM = (int) receiveObject();
                    ArrayList<TayDua> arlSach = ConnectDBDk.docSachTheoPhieu(maPM);
                    PMTemp phieuMuon = ConnectDBDk.timPM(maPM);
                    sendResult(phieuMuon);
                    sendResult(arlSach);
                    sendResult(arlTinhTrang);
                    //sendResult(arlMoTa);
                    break;
                }
                case "XoaPhieuMuon": {
                    int maPm = (int) receiveObject();
                    if (ConnectDBDk.xoaPM(maPm) && ConnectDBDk.xoaPMTrongBangDSSM(maPm)) {
                        sendResult("success");
                    }  /*              case "SuaBD": {
                    Chang bd = (Chang) receiveObject();
                    if (ConnectDBChang.capNhatBanDoc(bd)) {
                        sendResult("success");
                    } else {
                        sendResult("fail");
                    }
                    break;
                }
                case "timSach": {
                    String tenS = (String) receiveObject();
                    ArrayList<TayDua> arlS = ConnectDBTayDua.timSachTheoTen(tenS);
                    sendResult(arlS);
                    break;
                }
                case "SuaSach": {
                    TayDua s = (TayDua) receiveObject();
                    if (ConnectDBTayDua.capNhatSach(s)) {
                        sendResult("success");
                    } else {
                        sendResult("fail");
                    }
                    break;
                }
                case "ThemPhieuMuon": {
                    DangKi phieuMuon = (DangKi) receiveObject();
                    ConnectDBDk.themDanhSachSachMuon(phieuMuon);
                    sendResult("success");
                    ArrayList<PMTemp> arl = ConnectDBDk.docPMT();
                    sendResult(arl);
                    break;
                }
                case "HTSachMuonCuaBD": {
                    int maphieu = (int) receiveObject();
                    ArrayList<TayDua> arl = ConnectDBDk.docSachTheoPhieu(maphieu);
                    sendResult(arl);
                    break;
                }
                case "CheckBanDoc": {
                    Chang bd = (Chang) receiveObject();
                    if (ConnectDBDk.checkBanDoc(bd.getMaBD())) {
                        sendResult("true");
                    } else {
                        sendResult("false");
                    }
                    break;
                }
                case "TimPhieuMuon": {
                    int maPM = (int) receiveObject();
                    ArrayList<TayDua> arlSach = ConnectDBDk.docSachTheoPhieu(maPM);
                    PMTemp phieuMuon = ConnectDBDk.timPM(maPM);
                    sendResult(phieuMuon);
                    sendResult(arlSach);
                    sendResult(arlTinhTrang);
                    //sendResult(arlMoTa);
                    break;
                }
                case "XoaPhieuMuon": {
                    int maPm = (int) receiveObject();
                    if (ConnectDBDk.xoaPM(maPm) && ConnectDBDk.xoaPMTrongBangDSSM(maPm)) {
                        sendResult("success");
                    }  /*              case "SuaBD": {
                    Chang bd = (Chang) receiveObject();
                    if (ConnectDBChang.capNhatBanDoc(bd)) {
                        sendResult("success");
                    } else {
                        sendResult("fail");
                    }
                    break;
                }
                case "timSach": {
                    String tenS = (String) receiveObject();
                    ArrayList<TayDua> arlS = ConnectDBTayDua.timSachTheoTen(tenS);
                    sendResult(arlS);
                    break;
                }
                case "SuaSach": {
                    TayDua s = (TayDua) receiveObject();
                    if (ConnectDBTayDua.capNhatSach(s)) {
                        sendResult("success");
                    } else {
                        sendResult("fail");
                    }
                    break;
                }
                case "ThemPhieuMuon": {
                    DangKi phieuMuon = (DangKi) receiveObject();
                    ConnectDBDk.themDanhSachSachMuon(phieuMuon);
                    sendResult("success");
                    ArrayList<PMTemp> arl = ConnectDBDk.docPMT();
                    sendResult(arl);
                    break;
                }
                case "HTSachMuonCuaBD": {
                    int maphieu = (int) receiveObject();
                    ArrayList<TayDua> arl = ConnectDBDk.docSachTheoPhieu(maphieu);
                    sendResult(arl);
                    break;
                }
                case "CheckBanDoc": {
                    Chang bd = (Chang) receiveObject();
                    if (ConnectDBDk.checkBanDoc(bd.getMaBD())) {
                        sendResult("true");
                    } else {
                        sendResult("false");
                    }
                    break;
                }
                case "TimPhieuMuon": {
                    int maPM = (int) receiveObject();
                    ArrayList<TayDua> arlSach = ConnectDBDk.docSachTheoPhieu(maPM);
                    PMTemp phieuMuon = ConnectDBDk.timPM(maPM);
                    sendResult(phieuMuon);
                    sendResult(arlSach);
                    sendResult(arlTinhTrang);
                    //sendResult(arlMoTa);
                    break;
                }
                case "XoaPhieuMuon": {
                    int maPm = (int) receiveObject();
                    if (ConnectDBDk.xoaPM(maPm) && ConnectDBDk.xoaPMTrongBangDSSM(maPm)) {
                        sendResult("success");
                    }  /*              case "SuaBD": {
                    Chang bd = (Chang) receiveObject();
                    if (ConnectDBChang.capNhatBanDoc(bd)) {
                        sendResult("success");
                    } else {
                        sendResult("fail");
                    }
                    break;
                }
                case "timSach": {
                    String tenS = (String) receiveObject();
                    ArrayList<TayDua> arlS = ConnectDBTayDua.timSachTheoTen(tenS);
                    sendResult(arlS);
                    break;
                }
                case "SuaSach": {
                    TayDua s = (TayDua) receiveObject();
                    if (ConnectDBTayDua.capNhatSach(s)) {
                        sendResult("success");
                    } else {
                        sendResult("fail");
                    }
                    break;
                }
                case "ThemPhieuMuon": {
                    DangKi phieuMuon = (DangKi) receiveObject();
                    ConnectDBDk.themDanhSachSachMuon(phieuMuon);
                    sendResult("success");
                    ArrayList<PMTemp> arl = ConnectDBDk.docPMT();
                    sendResult(arl);
                    break;
                }
                case "HTSachMuonCuaBD": {
                    int maphieu = (int) receiveObject();
                    ArrayList<TayDua> arl = ConnectDBDk.docSachTheoPhieu(maphieu);
                    sendResult(arl);
                    break;
                }
                case "CheckBanDoc": {
                    Chang bd = (Chang) receiveObject();
                    if (ConnectDBDk.checkBanDoc(bd.getMaBD())) {
                        sendResult("true");
                    } else {
                        sendResult("false");
                    }
                    break;
                }
                case "TimPhieuMuon": {
                    int maPM = (int) receiveObject();
                    ArrayList<TayDua> arlSach = ConnectDBDk.docSachTheoPhieu(maPM);
                    PMTemp phieuMuon = ConnectDBDk.timPM(maPM);
                    sendResult(phieuMuon);
                    sendResult(arlSach);
                    sendResult(arlTinhTrang);
                    //sendResult(arlMoTa);
                    break;
                }
                case "XoaPhieuMuon": {
                    int maPm = (int) receiveObject();
                    if (ConnectDBDk.xoaPM(maPm) && ConnectDBDk.xoaPMTrongBangDSSM(maPm)) {
                        sendResult("success");
                    }
                }*/
            }
        }
    }
}
