/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Ve;

public class ConnectDBVe {

    private static Connection conn;

    public static void ThemVe(Ve ve) {
        try {
            System.out.println(ve.getKhachhang().getTenKH());
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Ve VALUES(?,?,?,?,?,?)");
            ps.setInt(1, ve.getTour().getMatour());
            ps.setInt(2, ve.getDiadiem().getMaDd());
            ps.setInt(3, ve.getKhachhang().getMaKH());
            ps.setString(4, ve.getNgaydi());
            ps.setInt(5, ve.getSoluongkhach());
            ps.setDouble(6, ve.getTongtien());
            ps.executeUpdate();
            ps.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public static boolean CheckVeKH(int MaKH, String Ngay) {
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Ve WHERE MaKH=? AND NgayDi=?");
            ps.setInt(1, MaKH);
            ps.setString(2, Ngay);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                return true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }
    /*public static Ve TimVetheoIDKH(int id) {
        Ve doi = null;
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM DoiDua WHERE idDoi =?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
               doi = new Ve(rs.getInt("idDoi"),
                       rs.getString("tenDoi"),
                       rs.getString("hang"),
                       rs.getString("moTa"));
            }
            ps.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return doi;
    }
*/
/*    public static void themBanDoc(Chang bd) {
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO BanDoc VALUES(?,?,?,?,?,?,?,?)");
            ps.setString(1, bd.getMaBD());
            ps.setString(2, bd.getHoTen());
            ps.setString(3, bd.getNgaySinh());
            ps.setString(4, bd.getGioiTinh());
            ps.setString(5, bd.getKhoa());
            ps.setInt(6, bd.getKhoaHoc());
            ps.setString(7, bd.getEmail());
            ps.setString(8, bd.getChucVu());
            ps.executeUpdate();
            ps.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }*/

    /*public static ArrayList<Ve> timDoitheoten(String ten) {
        ArrayList<Ve> arlBD = new ArrayList<>();
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps;
            if ("".equals(ten)) {
                ps = conn.prepareStatement("SELECT * FROM DoiDua");
            } else {
                ps = conn.prepareStatement("SELECT * FROM DoiDua WHERE tenDoi LIKE ?");
                ps.setString(1, "%" + ten + "%");
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Ve doi = new Ve(rs.getInt("idDoi"),
                       rs.getString("tenDoi"),
                       rs.getString("hang"),
                       rs.getString("moTa"));         
                arlBD.add(doi);
            }
        } catch (Exception ex) {
            Logger.getLogger(ConnectDBVe.class.getName()).log(Level.SEVERE, null, ex);
        }
        return arlBD;
    }
*/
    
}
