/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Tour;

public class ConnectDBTour {

    private static Connection conn;

    public static Tour TimChang(int id) {
        Tour chang = null;
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM ChangDua WHERE idChang =?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
               chang = new Tour(rs.getInt("idChang"),
                       rs.getString("tenChang"),
                       rs.getInt("soVong"),
                       rs.getString("diaDiem"),
                       rs.getString("thoiGian"),
                       rs.getString("moTa"),
                        rs.getBoolean("TrangThai"));
            }
            ps.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return chang;
    }

/*    public static void themBanDoc(Chang bd) {
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO BanDoc VALUES(?,?,?,?,?,?,?,?)");
            ps.setString(1, bd.getMaBD());
            ps.setString(2, bd.getHoTen());
            ps.setString(3, bd.getNgaySinh());
            ps.setString(4, bd.getGioiTinh());
            ps.setString(5, bd.getKhoa());
            ps.setInt(6, bd.getKhoaHoc());
            ps.setString(7, bd.getEmail());
            ps.setString(8, bd.getChucVu());
            ps.executeUpdate();
            ps.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }*/

    public static ArrayList<Tour> timTourtheodiemden(String Var) {
        ArrayList<Tour> arlTour = new ArrayList<>();
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps;
            if ("".equals(Var)) {
                ps = conn.prepareStatement("SELECT * FROM Tour");
            } else {
                ps = conn.prepareStatement("SELECT * FROM Tour WHERE MaDD LIKE ?");
                int idDD = ConnectDBDiadiem.timDiadiemtheoten(Var).getMaDd();
                ps.setInt(1, idDD );
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Tour tour = new Tour(rs.getInt("MaTour"),
                       rs.getString("TenTour"),
                       rs.getString("NoiDi"),
                       ConnectDBDiadiem.timDiadiemtheoten(Var),
                       rs.getFloat("GiaTour"),
                       rs.getString("MoTa"));
                arlTour.add(tour);
            }
        } catch (Exception ex) {
            Logger.getLogger(ConnectDBTour.class.getName()).log(Level.SEVERE, null, ex);
        }
        return arlTour;
    }

    public static boolean capNhatChang(Tour ch) {
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("UPDATE ChangDua SET TrangThai=? WHERE idChang=?");
            ps.setBoolean(1, true);
            ps.setInt(2, ch.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }
}
