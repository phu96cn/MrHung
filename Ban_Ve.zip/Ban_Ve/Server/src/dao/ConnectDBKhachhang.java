/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.spi.DirStateFactory;
import model.KhachHang;

public class ConnectDBKhachhang {

    static Connection conn;

 /*   public static void themSach(TayDua s) {
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Sach VALUES(?,?,?,?)");
            ps.setString(1, s.getTenS());
            ps.setString(2, s.getTacGia());
            ps.setInt(3, s.getNamXB());
            ps.setString(4, s.getMoTa());
            ps.executeUpdate();
            ps.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
*/
    public static ArrayList<KhachHang> timTayDuaTheoTen(String tenS) {
        ArrayList<KhachHang> arls = new ArrayList<>();
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps;
            if ("".equals(tenS)) {
                ps = conn.prepareStatement("SELECT * FROM TayDua");
            } else {
                ps = conn.prepareStatement("SELECT * FROM TayDua WHERE tenTayDua LIKE ?");
                ps.setString(1, "%" + tenS + "%");
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                arls.add(new KhachHang(rs.getInt("idTayDua"),
                        ConnectDBVe.TimDoi(rs.getInt("idDoi")),
                        rs.getString("tenTayDua"),
                        rs.getString("ngaySinh"),
                        rs.getString("quocTich"),
                        rs.getString("tieuSu")));
            }
            rs.close();
            ps.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return arls;
    }

 /*   public static boolean capNhatSach(TayDua s) {
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("UPDATE Sach SET tenSach=?,tacGia=?,namXB=?,moTa=? WHERE maSach=?");
            ps.setString(1, s.getTenS());
            ps.setString(2, s.getTacGia());
            ps.setInt(3, s.getNamXB());
            ps.setString(4, s.getMoTa());
            ps.setInt(5, s.getMaS());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }*/
    public static KhachHang timTayDuaTheoMa(int maS){
        KhachHang s = null;
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM TayDua WHERE idTayDua=?");
            ps.setInt(1, maS);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                s = new KhachHang(rs.getInt("idTayDua"),
                        ConnectDBVe.TimDoi(rs.getInt("idDoi")),
                        rs.getString("tenTayDua"),
                        rs.getString("ngaySinh"),
                        rs.getString("quocTich"),
                        rs.getString("tieuSu"));
            }
            rs.close();
            ps.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return s;
    }
}
