/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectDB {
    public static Connection connectDB() throws Exception{
        Connection con = null;
        String User = "sa";
        String Pass = "root";
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");//Đăng ký driver
        String connectionURL = "jdbc:sqlserver://ADMIN88-PC:1433;databaseName=TotNo";
        con = DriverManager.getConnection(connectionURL,User,Pass);
        return con;
    }
}
