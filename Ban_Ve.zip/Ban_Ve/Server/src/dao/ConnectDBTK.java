/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Admin;

public class ConnectDBTK {
    static Connection conn;
    public static boolean checkLogin(Admin tk){
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Admin WHERE userName=? AND passWord=?");
            ps.setString(1, tk.getUsername());
            ps.setString(2, tk.getPass());
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                return true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }
}
