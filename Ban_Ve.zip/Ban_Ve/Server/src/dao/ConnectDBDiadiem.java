/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Tour;
import model.Diadiem;
import model.KhachHang;

public class ConnectDBDiadiem {

    private static Connection conn;
  //  public static ArrayList<String> arlTinhTrang = new ArrayList<>();
   // public static ArrayList<Integer> arlMoTa = new ArrayList<>();

/*    public static void themPM(DangKi pm) {
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO PhieuMuon VALUES(?,?,?)");
            ps.setString(1, pm.getId().getMaBD());
            ps.setString(2, pm.getNgayMuon());
            ps.setString(3, pm.getNgayTra());
            ps.executeUpdate();
            ps.close();
            conn.close();
        } catch (Exception ex) {
            Logger.getLogger(ConnectDk.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/

    /*public static ArrayList<Diadiem> DSDangKi() {
        ArrayList<Diadiem> arlPMtemp = new ArrayList<>();
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM DangKy");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                arlPMtemp.add(new Diadiem(rs.getInt("idDangKy"),
                        ConnectDBTour.TimChang(rs.getInt("idChang")),
                        ConnectDBVe.TimDoi(rs.getInt("idDoi")),
                        ConnectDBKhachhang.timTayDuaTheoMa(rs.getInt("idTayDua")),
                        rs.getString("NgayDK"),
                        rs.getInt("ThoiGian"),
                        rs.getInt("SoVong")));
            }
            rs.close();
            ps.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return arlPMtemp;
    }
*/
 /*   public static void themDanhSachSachMuon(DangKi pm) {
        try {
            themPM(pm);
            ArrayList<PMTemp> arlmaPM = docPMT();
            int i = 0;
            PreparedStatement ps = null;
            for (TayDua s : pm.getArlSM()) {
                conn = ConnectDB.connectDB();
                ps = conn.prepareStatement("INSERT INTO DanhSachSachMuon VALUES(?,?,?,?)");
                ps.setInt(1, arlmaPM.get(arlmaPM.size() - 1).getMaPM());
                ps.setInt(2, s.getMaS());
                ps.setString(3, pm.getArlTT().get(i++));
                ps.setInt(4, pm.getMoTa());
                ps.executeUpdate();
            }
            ps.close();
            conn.close();
        } catch (Exception ex) {
            Logger.getLogger(ConnectDk.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/

  /*  public static ArrayList<KhachHang> DSTayDuaTheoIDChang(int idchang) {
        ArrayList<KhachHang> arT = new ArrayList<>();
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM DangKy WHERE idChang=?");
            ps.setInt(1, idchang);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                arT.add(ConnectDBKhachhang.timTayDuaTheoMa(rs.getInt("idTayDua")));
  //              arlTinhTrang.add(rs.getString("tinhTrang"));
         //       arlMoTa.add(rs.getInt("moTa"));
            }
            rs.close();
            ps.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return arT;
    }
    public static boolean capNhatDangKi(Diadiem dk) {
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("UPDATE DangKy SET thoiGian=?,soVong=? WHERE idChang=? AND idTayDua=?");
            ps.setInt(1, dk.getThoigian());
            ps.setInt(2, dk.getSovong());
            ps.setInt(3, dk.getChang().getId());
            ps.setInt(4, dk.getTaydua().getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }
    */
 /*   public static boolean checkBanDoc(String maBD) {

        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM PhieuMuon WHERE maBD =?");
            ps.setString(1, maBD);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                if (rs.getInt("moTa") == 0) {
                    return false;
                }
            }
            ps.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return true;
    }
*/
    public static ArrayList<Diadiem> timDiadiemtheoten(String var){
        ArrayList<Diadiem> arldd = new ArrayList<>();
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps;
            if ("".equals(var)) {
                ps = conn.prepareStatement("SELECT * FROM DiaDiem");
            } else {
                ps = conn.prepareStatement("SELECT * FROM DiaDiem WHERE TenDD LIKE ?");
                ps.setString(1,"%" + var + "%");
                System.out.println(var);
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Diadiem dd = new Diadiem(rs.getInt("MaDD"),
                       rs.getString("TenDD"),
                       rs.getString("DiaChi"),
                       rs.getString("MoTa"));
                arldd.add(dd);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return arldd;
    }

    public static Diadiem timDiadiemtheoid(int var){
        Diadiem dd = null;
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM DiaDiem WHERE MaDD =?");
            ps.setInt(1, var);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                dd = new Diadiem(rs.getInt("MaDD"),
                       rs.getString("TenDD"),
                       rs.getString("DiaChi"),
                       rs.getString("MoTa"));
            }
        } catch (Exception ex) {
            Logger.getLogger(ConnectDBDiadiem.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dd;
    }
 /*   public static boolean xoaPM(int maPM) {
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("DELETE FROM PhieuMuon WHERE maPM=?");
            ps.setInt(1, maPM);
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }*/
 /*    public static boolean xoaPMTrongBangDSSM(int maPM) {
        try {
            conn = ConnectDB.connectDB();
            PreparedStatement ps = conn.prepareStatement("DELETE FROM DanhSachSachMuon WHERE maPM=?");
            ps.setInt(1, maPM);
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }*/
}
