/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import javax.swing.JDialog;
import javax.swing.JFrame;

public class HoaDonDialog extends JDialog{
    public HoaDonDialog(JFrame fr, String title) {
        super(fr, title);
        HoaDon th1 = new HoaDon();
        getContentPane().add(th1);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
    }
}
