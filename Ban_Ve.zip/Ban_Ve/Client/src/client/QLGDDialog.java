/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import javax.swing.JDialog;
import javax.swing.JFrame;

/**
 *
 * @author Kieu Viet Quan
 */
public class QLGDDialog extends JDialog{
    public QLGDDialog(JFrame fr, String title) {
        super(fr, title);
        QuanLyGiaiDua th1 = new QuanLyGiaiDua();
        getContentPane().add(th1);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
    }
}
