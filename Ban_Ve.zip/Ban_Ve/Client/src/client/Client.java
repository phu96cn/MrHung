
package client;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Client {

   private String serverHost = "localhost";
    private int serverPort = 7575;
    private Socket mySocket;
 
    public Client(){
        
    }
    
    public void openConnection() throws Exception {
        mySocket = new Socket(serverHost, serverPort);
    }
    
    public void closeConnecttion() throws Exception {
        mySocket.close();
    }
    
    public void sendObject(Object obj) throws Exception {
        ObjectOutputStream oos = new ObjectOutputStream(mySocket.getOutputStream());
        oos.writeObject(obj);
    }
    
    public Object receiveObject() throws Exception {
        ObjectInputStream ois = new ObjectInputStream(mySocket.getInputStream());
        return ois.readObject();
    }
    
    
}
