/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import javax.swing.JDialog;
import javax.swing.JFrame;

/**
 *
 * @author Kieu Viet Quan
 */
public class PhieuMuonDialog extends JDialog{

    public PhieuMuonDialog(JFrame fr, String title) {
        super(fr, title);
        ThemPhieuMuon pm = new ThemPhieuMuon();
        getContentPane().add(pm);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
    }
    
}
