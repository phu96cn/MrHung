/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Kieu Viet Quan
 */
public class ConnectDB {
    public static Connection connectDB() throws Exception{
        Connection con = null;
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");//Đăng ký driver
        String connectionURL = "jdbc:sqlserver://localhost:1433;databaseName=F1;user=sa;password=Mylady.1996";
        con = DriverManager.getConnection(connectionURL);
        return con;
    }
}
