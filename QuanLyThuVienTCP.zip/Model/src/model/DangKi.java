/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Kieu Viet Quan
 */
public class DangKi implements Serializable{
    private int Id;
    private Chang chang;
    private TayDua taydua;
    private DoiDua doidua;
    private String NgayDk;
    private String thoigian;
    private int sovong;

    public DangKi(int Id, Chang chang,  DoiDua doidua, TayDua taydua,String NgayDk, String thoigian, int sovong) {
        this.Id = Id;
        this.chang = chang;
        this.taydua = taydua;
        this.doidua = doidua;
        this.NgayDk = NgayDk;
        this.thoigian = thoigian;
        this.sovong = sovong;
    }

    

    public DangKi() {
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public Chang getChang() {
        return chang;
    }

    public void setChang(Chang chang) {
        this.chang = chang;
    }

    public TayDua getTaydua() {
        return taydua;
    }

    public void setTaydua(TayDua taydua) {
        this.taydua = taydua;
    }

    public DoiDua getDoidua() {
        return doidua;
    }

    public void setDoidua(DoiDua doidua) {
        this.doidua = doidua;
    }

    public String getNgayDk() {
        return NgayDk;
    }

    public void setNgayDk(String NgayDk) {
        this.NgayDk = NgayDk;
    }

    public String getThoigian() {
        return thoigian;
    }

    public void setThoigian(String thoigian) {
        this.thoigian = thoigian;
    }

    public int getSovong() {
        return sovong;
    }

    public void setSovong(int sovong) {
        this.sovong = sovong;
    }

  
}
