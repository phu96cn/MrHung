/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author Kieu Viet Quan
 */
public class TayDua implements Serializable{   
    private int Id;
    private int IdDoi;
    private String Ten;
    private String NgaySinh;
    private String QuocTich;
    private String TieuSu;

    public TayDua(int Id, int IdDoi, String Ten, String NgaySinh, String QuocTich, String TieuSu) {
        this.Id = Id;
        this.IdDoi = IdDoi;
        this.Ten = Ten;
        this.NgaySinh = NgaySinh;
        this.QuocTich = QuocTich;
        this.TieuSu = TieuSu;
    }

    public TayDua() {
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public int getIdDoi() {
        return IdDoi;
    }

    public void setIdDoi(int IdDoi) {
        this.IdDoi = IdDoi;
    }

    public String getTen() {
        return Ten;
    }

    public void setTen(String Ten) {
        this.Ten = Ten;
    }

    public String getNgaySinh() {
        return NgaySinh;
    }

    public void setNgaySinh(String NgaySinh) {
        this.NgaySinh = NgaySinh;
    }

    public String getQuocTich() {
        return QuocTich;
    }

    public void setQuocTich(String QuocTich) {
        this.QuocTich = QuocTich;
    }

    public String getTieuSu() {
        return TieuSu;
    }

    public void setTieuSu(String TieuSu) {
        this.TieuSu = TieuSu;
    }

    
    public Object[] toObjects(){
        return new Object[]{this.Id, this.IdDoi, this.Ten, this.NgaySinh, this.QuocTich, this.TieuSu};
    }
}
