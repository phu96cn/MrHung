/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author Kieu Viet Quan
 */
public class DoiDua implements Serializable{
    private int Id;
    private String Ten;
    private String Hang;
    private String Mota;

    public DoiDua() {
    }

    public DoiDua(int Id, String Ten, String Hang, String Mota) {
        this.Id = Id;
        this.Ten = Ten;
        this.Hang = Hang;
        this.Mota = Mota;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getTen() {
        return Ten;
    }

    public void setTen(String Ten) {
        this.Ten = Ten;
    }

    public String getHang() {
        return Hang;
    }

    public void setHang(String Hang) {
        this.Hang = Hang;
    }

    public String getMota() {
        return Mota;
    }

    public void setMota(String Mota) {
        this.Mota = Mota;
    }

    
    
}
