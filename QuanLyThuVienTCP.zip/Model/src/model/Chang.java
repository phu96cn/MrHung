/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author Kieu Viet Quan
 */
public class Chang implements Serializable{
    private int Id;
    private String Ten;
    private int SoVong;
    private String Diadiem;
    private String Thoigian;
    private String Mota;

    public Chang(int Id, String Ten, int SoVong, String Diadiem, String Thoigian, String Mota) {
        this.Id = Id;
        this.Ten = Ten;
        this.SoVong = SoVong;
        this.Diadiem = Diadiem;
        this.Thoigian = Thoigian;
        this.Mota = Mota;
    }

    public Chang() {
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getTen() {
        return Ten;
    }

    public void setTen(String Ten) {
        this.Ten = Ten;
    }

    public int getSoVong() {
        return SoVong;
    }

    public void setSoVong(int SoVong) {
        this.SoVong = SoVong;
    }

    public String getDiadiem() {
        return Diadiem;
    }

    public void setDiadiem(String Diadiem) {
        this.Diadiem = Diadiem;
    }

    public String getThoigian() {
        return Thoigian;
    }

    public void setThoigian(String Thoigian) {
        this.Thoigian = Thoigian;
    }

    public String getMota() {
        return Mota;
    }

    public void setMota(String Mota) {
        this.Mota = Mota;
    }

    
    public Object[] toObjects(){
        return new Object[]{this.Id,this.Ten, this.SoVong, this.Diadiem, this.Thoigian, this.Mota};
    }

    
    
}

